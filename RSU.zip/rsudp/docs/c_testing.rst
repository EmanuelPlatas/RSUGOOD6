:py:data:`rsudp.c_testing` (test consumer)
=====================================================

.. automodule:: rsudp.c_testing
    :members:

................

* :ref:`genindex`
* :ref:`search`
.. * :ref:`modindex`

`Back to top ↑ <#top>`_
