:py:data:`rsudp.c_plot` (plot data)
=====================================================

.. _event_plot:
.. figure::  _static/event.png
    :align:   center

    An event recorded on a vertical geophone by rsudp and saved by the plotting module.


.. automodule:: rsudp.c_plot
    :members:

................

* :ref:`genindex`
* :ref:`search`
.. * :ref:`modindex`

`Back to top ↑ <#top>`_
